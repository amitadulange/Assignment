<?php
session_start();
error_reporting(0);
$server="localhost";
  $username="root";
  $password="";
  $db="demos";
  $connect = mysqli_connect($server,$username,$password,$db);

 if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
  //$smsg = "Already Logged In" . $_SESSION['username'];
  header('location:index.php');
} 
?>
<?php 
  
  $result=$connect->query(" SELECT * FROM material ");
 $row = mysqli_num_rows($result);

 $vendors=$connect->query("SELECT * FROM vendors ");
 $ven = mysqli_num_rows($vendors);
 
 $customer= $connect->query("SELECT * FROM customer_registration");
 $customer = mysqli_num_rows($customer);

  $Pendingpayment= $connect->query("SELECT * FROM grnstatus where paymentstatus='Unpaid' and paymentstatus='Partially Paid'  ");
 $Pendingpayment = mysqli_num_rows($Pendingpayment);



$NewDate=Date('y:m:d');

$que="SELECT * FROM salestatus where movtype='Sold' and (payment ='Unpaid' OR  payment ='Partially Paid') AND duedate > '".$NewDate."' order by id desc";

$t=mysqli_query($connect,$que);
$t1 = mysqli_num_rows($t);
//echo $t1;
//echo $t;


$username = $_SESSION['username'];

    $sql = "SELECT * FROM `registration` WHERE username='$username'";
    $res = mysqli_query($connect, $sql);
    $r = mysqli_fetch_assoc($res);
    $pic=$r['profilepic'];
    $loc='img/uploads/';

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <title>Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>


<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
         <!-- <i class="fas fa-laugh-wink"></i>-->
        </div>
        <div class="sidebar-brand-text mx-3">Hello</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

<?php if( ($r['role']=="User") ||  ($r['role']=="Admin")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="Customer_data/display_customer.php" data-toggle="collapse" data-target="#customer" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-users"></i>
          <span>Customer</span>
        </a>
        <div id="customer" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="Customer_data/display_customer.php">Customer List</a>
            
          </div>
        </div>
      </li>'; }?> 
    
<?php if(($r['venpermission']=='Y' && $r['role']=="User") || ($r['venpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="Vendor_data/display_vendor.php" data-toggle="collapse" data-target="#vendor" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-users"></i>
          <span>Vendor</span>
        </a>
        <div id="vendor" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="coll  apse-item" href="Vendor_data/add_vendor.php">Add New Vendor</a>
            <a class="collapse-item" href="Vendor_data/display_vendor.php">Vendor List</a>
            
          </div>
        </div>
      </li>'; }?>  

<?php if(($r['matpermission']=='Y' && $r['role']=="User") || ($r['matpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="Material_data/material_table.php" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-shopping-cart"></i>
          <span>Material Master</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"> 
      <a class="collapse-item" href="Material_data/add_material.php">Add New Material</a>
            <a class="collapse-item" href="Material_data/material_table.php">Material Master</a>
            <a class="collapse-item" href="Material_data/material_storage.php">Storage Location</a>
            <a class="collapse-item" href="Material_data/material_material_type.php">Material Type</a>
            <a class="collapse-item" href="Material_data/material_uom.php">UOM</a>
            <a class="collapse-item" href="Material_data/material_hsncode.php">Material HSN Code</a>
             <a class="collapse-item" href="Material_data/material_group.php">Material Group</a>
              <a class="collapse-item" href="Material_data/material_brand.php">Material Brand</a>
             <a class="collapse-item" href="Material_data/expiry_material.php">Material Settings</a>
             <a class="collapse-item" href="Plant/createplant.php">Create Plant</a>
             <a class="collapse-item" href="Plant/plantlist.php">Plant List</a>
           
            
          </div>
        </div>
      </li>'; }?>


<?php if(($r['grnpermission']=='Y' && $r['role']=="User") || ($r['grnpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="PO/grn.php" data-toggle="collapse" data-target="#grn" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-edit"></i>
          <span>Purchase Invoice</span>
        </a>
        <div id="grn" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="grn/grn.php">New Purchase Invoice</a>
            <a class="collapse-item" href="grn/grnlist.php">Purchase Invoice List</a>
             <a class="collapse-item" href="grn/display_grnreturn.php">Purchase Return List</a>  
             <a class="collapse-item" href="grn/display_creditnote.php">Credit Note List</a>          
          </div>
        </div>
      </li>'; }?>

<?php if(($r['popermission']=='Y' && $r['role']=="User") || ($r['popermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="sale/create_sale.php" data-toggle="collapse" data-target="#sale" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="  fas fa-chart-line"></i>
          <span>Sales</span>
        </a>
        <div id="sale" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="sale/create_sale.php">New Sales</a>
            <a class="collapse-item" href="sale/display_sale.php"> Sales List</a>
             <a class="collapse-item" href="sale/duepayment_sale.php"> Due List</a>
             <a class="collapse-item" href="sale/display_returnsale.php">Sales Return List</a>
             <a class="collapse-item" href="sale/due_returnpaidlist.php">Due Return List</a>
            
             <a class="collapse-item" href="sale/debitlist.php">Debit List</a>
            
          </div>
        </div>
      </li>'; }?> 


  <!--  <?php if(($r['popermission']=='Y' && $r['role']=="User") || ($r['popermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="Chalan/DC.php" data-toggle="collapse" data-target="#Chalan" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="  fas fa-chart-line"></i>
          <span>Chalan</span>
        </a>
        <div id="Chalan" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="Chalan/DC.php">New DC</a>
            <a class="collapse-item" href="Chalan/dclist.php">DC List</a>
             <a class="collapse-item" href="Chalan/vareceived_list.php">Vendor Received List</a>
             <a class="collapse-item" href="Chalan/dcreturn_list.php.php">Return list</a>
            
            
          </div>
        </div>
      </li>'; }?> --> 



<?php if(($r['prpermission']=='Y' && $r['role']=="User") || ($r['prpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Estimate" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-chart-line"></i>
          <span>Job Card & Estimate</span>
        </a>
        <div id="Estimate" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="jobcard/jobcard.php">New Job Card</a>
            <a class="collapse-item" href="jobcard/jobcardlist.php">Job Card List</a>
             <a class="collapse-item" href="jobcard/display_estimate.php">Estimate List</a>
            
            
          </div>
        </div>
      </li>'; }?>  
  


<?php if(($r['invenpermission']=='Y' && $r['role']=="User") || ($r['invenpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="Inventry/inventry.php" data-toggle="collapse" data-target="#inventry" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Inventory</span>
        </a>
        <div id="inventry" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="Inventry/inventry.php">Stock List</a>
            
          </div>
        </div>
      </li>'; }?>   


<?php if(($r['accpermission']=='Y' && $r['role']=="User") || ($r['accpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#account" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-landmark"></i>
          <span>Account</span>
        </a>
        <div id="account" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="Account/COA.php">COA</a>
            <a class="collapse-item" href="Account/Genral_ledger.php">GL</a>
             <a class="collapse-item" href="Account/advancepayment.php">Payments</a>
              <a class="collapse-item" href="Account/voucher_status.php">Voucher List</a>
               <a class="collapse-item" href="Account/add_voucher.php">New Voucher</a>
               <a class="collapse-item" href="Account/reports.php">Reports</a>
               <a class="collapse-item" href="Expenses/expenses.php">Expenses</a>
                <a class="collapse-item" href="capital_goods/capital_goods.php">Capital Goods/ Assest</a>


            
          </div>
        </div>
      </li>'; }?>    


<?php if(($r['userpermission']=='Y' && $r['role']=="User") || ($r['userpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="user/index.php" data-toggle="collapse" data-target="#pr" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-portrait"></i>
          <span>User</span>
        </a>
        <div id="pr" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="user/index.php">User List</a>
            <a class="collapse-item" href="user/register.php">Add New User</a>
             <a class="collapse-item" href="setting/create_setting.php">Setting New User</a>
            
          </div>
        </div>
      </li>'; }?>



      <!-- Divider -->
     
      <hr class="sidebar-divider">
<?php if(($r['settpermission']=='Y' && $r['role']=="User") || ($r['settpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="")){ echo'

     <li class="nav-item">
        <a class="nav-link" href="setting/settinglist.php"  data-toggle="collapse" data-target="#pr1" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-cogs fa-sm fa-fw mr-2"></i>
          <span> Settings</span></a>


          <div id="pr1" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="setting/create_setting.php">Add Setting</a>
            <a class="collapse-item" href="setting/settinglist.php">Setting List</a>
          
            
            
          </div>
        </div>
      </li>'; }?>

     

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

           
           
            

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                  <?php echo $_SESSION['username'];?> </span>
                <img alt="User Pic" src="<?php if(isset($r['profilepic']) & !empty($r['profilepic'])){ echo "$loc$pic"; }else{ echo "img/user.png";} ?>" id="profileimage" class="img-profile rounded-circle"> 
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="setting/user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->


        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            
          </div>

          <!-- Content Row -->
          









          <div class="row">

           

          
         

           
           

        </div>
      </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
