<?php
session_start();

if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
  header('location: ../index.php');
}
require_once('../connect.php');

$str=$_GET['id'];


 $str_arr = preg_split ("/\,/", $str);  

   $id="$str_arr[0] ";
   $data= "$str_arr[1]";
  
if($data=='Y'){
	$sql= "UPDATE customer_registration SET enabled='Y' where id='$id'";
	$q=mysqli_query($connection,$sql);
}
elseif($data=='N'){
	//<option> yes </option>
	$sql0= "UPDATE customer_registration SET enabled='N' where id='$id'";
	$q0=mysqli_query($connection,$sql0);
}
else {
	//<option> yes </option>
	$sql1= "DELETE FROM customer_registration  where id='$id'";
	$q1=mysqli_query($connection,$sql1);
}

 header('location:display_customer.php');


?>
