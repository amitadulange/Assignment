<?php
session_start();
error_reporting(0);
require_once('../connect.php');

 if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
  //$smsg = "Already Logged In" . $_SESSION['username'];
  header('location:../index.php');
} 
$username = $_SESSION['username'];
$sql = mysqli_query($connection,"SELECT * FROM `registration` WHERE username='$username'");
    
    $r = mysqli_fetch_assoc($sql);
 if($r['role']=='Admin'){
        if($r['custpermission']=='N'&& $r['custpermission']=='Y' && $r['role'] !="Admin"){ 
          header('location:../index.php');
        }
    }
    if($r['role']=='HOD' || $r['role']=='User'){
        if($r['custpermission']=='N'){ 
          header('location:../index.php');
        }
    }
    
    $sql = "SELECT * FROM `registration` WHERE username='$username'";
    $res = mysqli_query($connection, $sql);
    $r = mysqli_fetch_assoc($res);
    $pic=$r['profilepic'];
    $loc='../img/uploads/';
?>
<?php
$sql1 = "SELECT * FROM `setting` WHERE id=1";
    $res1 = mysqli_query($connection, $sql1);
    $r1 = mysqli_fetch_assoc($res1);
    $logo=$r1['logo'];
    $loc1="../img/uploads/logo/"
    
  ?>


<!DOCTYPE html>
<html lang="en">

<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Update Customer</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <!-- jQuery UI -->
      <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
              <!-- Custom fonts for this template -->
      <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
      <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="../css/sb-admin-2.min.css" rel="stylesheet">
      <!-- Custom styles for this page -->
      <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="../css/custom.css">
      </link>
   </head>


<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    
        <!-- Begin Page Content -->

        <div class="container-fluid">

          <!-- Page Heading -->
          <?php


$id=$_GET['id'];

$selectquery="select * from customer_registration where id=$id";

$query=mysqli_query($connection,$selectquery);

$result=mysqli_fetch_assoc($query);

if(isset($_POST['submit']))
  {
    $id=$_POST['id'];
    $name=$_POST['name'];
    $mobileno=$_POST['mobileno'];
    $country=$_POST['country'];
    $state=$_POST['state'];
    $statecode=$_POST['statecode'];
    $city=$_POST['city'];
    $pin=$_POST['pin'];
    $address1=$_POST['address1'];
    $email=$_POST['email'];
 

   
    if(!isset($Err)){

$sql="update customer_registration set name='$name',address1='$address1',country='$country',state='$state',city='$city',statecode='$statecode',pin='$pin', mobileno='$mobileno',email='$email' where id=$id";


        if (mysqli_query($connection,$sql)) {
          $Err="Form Update Successfully"; 
          
          header("Location: display_customer.php");
           

 
}
 else {
    echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}
}
}
?>
<!--<!DOCTYPE html>
<html lang="en">

<head>-->
  <body class="bg-gradient-">

  <div class="container">
    <?php if(isset($Err)){ ?><div class="alert visible alert-success" role="alert"> <?php echo $Err; ?> </div><?php } ?>
    <a href="display_customer.php">
                                    <button class="btn btn-sm btn-primary m-2">Back</button>
                                  </a>
        <div class="row">
         <!-- <div class="col-lg-4 d-none d-lg-block bg-register-image"></div> -->
          <div class="col-lg-12">
        
          <div class="card o-hidden border-0 shadow-lg my-2">
            <div class="text-center modal-header bg-gradient-primary">
                      <h1 class="h4 text-white mb-2">Update Customer Form</h1>
                    </div>
            <div class="card-body p-0">
              <!-- Nested Row within Card Body -->
                <div class="p-3">
                    
                    <form class="user"  id="myform" onsubmit="return validateForm()"   method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  
                      
                      <br />
                      
                       <div class="form-row">
                         

                      <div class="col-md-3 mb-3">
                         <label>Name <sup class="text-danger font-weight-bold">*</sup>:</label>
                      
                        <input type="text" maxlength="40" class="form-control" name="name"     value="<?php echo $result['name'];?>" >
                        
                      </div>
                       
                     
 
                       <div class="col-md-4 mb-3">
                          <label>Address <sup class="text-danger font-weight-bold">*</sup> :</label>
                       
                        <input type="text"  class="form-control" name="address1" value="<?php echo $result['address1'];?>">
                      </div>
                    <div class="col-md-4 mb-3">
                        <label>Mobile No <sup class="text-danger font-weight-bold">*</sup> :</label>
                      
                          <input type="text" maxlength="10" class="form-control" name="mobileno" value="<?php echo $result['mobileno'];?>">
                        </div>
                        
                         
                     
                    </div>
                    <div class="form-row">
                        
                     <div class="col-md-4 mb-3">
                          <label>Country <sup class="text-danger font-weight-bold">*</sup>:</label>
                        
                        <input type="text" maxlength="40" class="form-control" name="country" value="<?php echo $result['country'];?>">

         
                      </div>
                    
                        <div class="col-md-4 mb-3">
                          <label>State :</label>
                        
                          <input type="text"maxlength="40" class="form-control"name="state" value="<?php echo $result['state'];?>">

                        

        
                      </div>


                      <div class="col-md-4 mb-3">
                          <label>City :</label>
                        
                        <input type="text"maxlength="40" class="form-control"name="city" value="<?php echo $result['city'];?>">


                      </div>
                    </div>
                      
                      <div class="form-row">
                     
                    
                       <div class="col-md-4 mb-3">
                          <label>State Code  :</label>
                        
                          <input type="text" class="form-control"name="statecode" value="<?php echo $result['statecode'];?>">
                        
                          
                      </div>
                     <div class="col-md-4 mb-3">
                          <label>Email  :</label>
                        
                        <input type="text" maxlength="60" class="form-control" name="email" value="<?php echo $result['email'];?>">
                      </div>
                   </div>
                        
                       
                      
                       <input type='text' class="form-control invisible" name ="id" value="<?php echo $result['id'];?>">
                      
                        




                        <div class="float-right col-md-3">
                                                                                <input  name="submit" type="submit" class="btn btn-primary  text-black  btn-block" value="submit">
                                                                                </div>
                      


  

                   
                    </form>
                
                    </div>
                  </div>
               </div>
              </div>
            </div>
          </div>
        </div>
  </div>


        <script type="text/javascript">
    $('body').on('keydown', 'input, select', function(e) {
    if (e.key === "Enter") {
        var self = $(this), form = self.parents('form:eq(0)'), focusable, next;
        focusable = form.find('input,a,select,button,textarea').filter(':visible');
        next = focusable.eq(focusable.index(this)+1);
        if (next.length) {
            next.focus();
        } else {
            form.submit();
        }
        return false;
    }
});
</script>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<!--</body>

</html>-->
 
    

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
   <script src="../vendor/jquery/jquery.min.js"></script>
                                                          <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                                                          <!-- Core plugin JavaScript-->
                                                          <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
                                                          <!-- Custom scripts for all pages-->
                                                          <script src="js/sb-admin-2.min.js"></script>
                                                          <!-- Page level plugins -->
                                                          <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
                                                          <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>
                                                          <!-- Page level custom scripts -->
                                                          <script src="../js/demo/datatables-demo.js"></script>
  


    <script type="text/javascript">
    $(function () {
               $("#selectgsttype").change(function () {

            if ($(this).val() == "Yes") {
                $("#gsttype").show();
            } else {
                $("#gsttype").hide();
            }
        });
    });
</script>



 <script>
function getdistrict(val) {
  $.ajax({
  type: "POST",
  url: "get_district.php",
  data:'state_id='+val,
  success: function(data){
    $("#district-list").html(data);
  }
  });
}
</script>
<script>
function getcode(val) {
  $.ajax({
  type: "POST",
  url: "get_citycode.php",
  data:'state_id='+val,
  success: function(data){
    $("#statecode").html(data);
  }
  });
}
</script>  
 <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../js/demo/datatables-demo.js"></script>


</body>

</html>
