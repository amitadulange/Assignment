<?php
//error_reporting(0);
session_start();
require_once ('../connect.php');

if (!isset($_SESSION['username']) & empty($_SESSION['username']))
{
    //$smsg = "Already Logged In" . $_SESSION['username'];
    header('location:../index.php');
}
$username = $_SESSION['username'];
$sql = mysqli_query($connection, "SELECT * FROM `registration` WHERE username='$username'");

$r = mysqli_fetch_assoc($sql);
if ($r['role'] == 'Admin')
{
    if ($r['custpermission'] == 'N' && $r['custpermission'] == 'Y' && $r['role'] != "Admin")
    {
        header('location:../index.php');
    }
}
if ($r['role'] == 'HOD' || $r['role'] == 'User')
{
    if ($r['custpermission'] == 'N')
    {
        header('location:../index.php');
    }
}
$query = "SELECT * from customer_registration order by id desc";
$result = mysqli_query($connection, $query);

$sql = "SELECT * FROM `registration` WHERE username='$username'";
$res = mysqli_query($connection, $sql);
$r = mysqli_fetch_assoc($res);
$pic = $r['profilepic'];
$role=$r['role'];
$loc = '../img/uploads/';

?>

<!DOCTYPE html>
<html lang="en">

<head>

      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>  Table</title>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>

  <!-- Custom fonts for this template -->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Custom styles for this page -->
  <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    


        <!-- Begin Page Content -->

        <div class="container-fluid">

          

                     
<div class="row"> 
  <?php if($role== 'Admin'){ echo '
              <a href="add_customer.php">
              <button class="btn btn-sm btn-primary m-2 ">Add New Customer</button> </a>';}?> 
                  
                
</div>
                 
        
 <div class="card shadow mb-4">
                     <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Table</h6>
                     </div>
                     <div class="card-body">
                        <div class="table-responsive">
                           <table class="table table-bordered table-hover table-striped table-sm" id="dataTable" width="100%" cellspacing="0" >
                              <thead  class="bg-gradient-primary text-white text-center" >
                  
          
                    <tr>
                      
    <th>Sr No.</th>      
   <!--  <th>Customer Code</S></th> -->
    <th> Customer Name </th>
     <th>Country</th>
     <th>State</th>
    <th>City</th>
    
    <!--  <th></th> -->
    <th>State Code</th> 
    <th>Mobile No</th>
   <!--  <th>Email Id</th> -->
    <!--  <th>Opening balance</th> -->
   
   <!--  <th>Debit</th> -->
   
    <?php if($role=='Admin'){ echo'<th> Delete </th> <th> Update </th>';} ?>
  
  </thead>
  </tr>

  <?php
$i = 1;
while ($row = mysqli_fetch_assoc($result))
{
?>
  <tr>
      <td><?php echo $i ?></td>
  <!--  <td> <a href="update_customer.php?id=<?php echo $row['id'] ?>"></a>
    <?php echo $row['customercode']?></td> -->
    <td ><?php echo $row['name'] ?></td>
      <td ><?php echo $row['country'] ?></td>
     <td ><?php echo $row['state'] ?></td>
    <td><?php echo $row['city'] ?></td>
   
    <td><?php echo $row['statecode'] ?></td>
    <td><?php echo $row['mobileno'] ?></td>
    <!-- <td><?php echo $row['email'] ?></td> -->
   <?php if($role=='Admin'){
    echo'
     <td>               
        <div class="row">
          <div class="col-sm-2">
          
                 <div class="col-sm-2">         
                        <button class="btn btn-info btn-sm mr-2"><a class="text-white" onclick="return confirm("Are you sure you want to Delete customer?");" href="customer_enabled.php?id='. $row["id"].', "D" ">D</a></button>
                </div>
            </div>                
        </td>

   
<td><button type="button" class="btn btn-sm btn-info"><a class="text-white" href="update_customer.php?id='. $row["id"].' "><i class="fas fa-edit"></i> </a></button></td>' ;}

?>
  </tr>
  <?php
    $i++;
}
?>
  </table>
 
   </div>
            </div>
          </div>
</div>
  <!-- End of Page Wrapper -->
    <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
<script type="text/javascript">
$(document).ready( function () {
    $('#dataTable').DataTable();
} );
</script>
   <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../js/demo/datatables-demo.js"></script>
 
</body>

</html>
