<?php
require_once("../connect.php");
if(!empty($_POST["state_id"])) 
{
$query =mysqli_query($connection,"SELECT * FROM city WHERE CityName = '" . $_POST["state_id"] . "'");

while($row1=mysqli_fetch_array($query)) 

{
	$code=$row1["StCode"];


	$q=mysqli_query($connection,"SELECT * FROM state WHERE id = $code");
	while($row=mysqli_fetch_array($q)) 

{
?>
<option value="<?php echo $row["StCode"]; ?>"><?php echo $row["StCode"]; ?></option>
<?php
}
}
}

?>
