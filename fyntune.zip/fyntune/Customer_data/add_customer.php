<?php
session_start();
error_reporting(0);
require_once('../connect.php');

 if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
  //$smsg = "Already Logged In" . $_SESSION['username'];
  header('location:index.php');
} 
$username = $_SESSION['username'];
$sql = mysqli_query($connection,"SELECT * FROM `registration` WHERE username='$username'");
    
    $r = mysqli_fetch_assoc($sql);
 if($r['role']=='Admin'){
        if($r['custpermission']=='N'&& $r['custpermission']=='Y' && $r['role'] !="Admin"){ 
          header('location:../index.php');
        }
    }
    if($r['role']=='HOD' || $r['role']=='User'){
        if($r['custpermission']=='N'){ 
          header('location:../index.php');
        }
    }


    

    $sql = "SELECT * FROM `registration` WHERE username='$username'";
    $res = mysqli_query($connection, $sql);
    $r = mysqli_fetch_assoc($res);
    $pic=$r['profilepic'];
    $loc='../img/uploads/';
 

 $sql1 = "SELECT * FROM `setting` WHERE id=1";
    $res1 = mysqli_query($connection, $sql1);
    $r1 = mysqli_fetch_assoc($res1);
    $logo=$r1['logo'];
    $loc1="../img/uploads/logo/";

  
    
  ?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>Add Customer</title>
     <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
      <!-- jQuery UI -->
      <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
              <!-- Custom fonts for this template -->
      <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"> 
      <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="../css/sb-admin-2.min.css" rel="stylesheet">
      <!-- Custom styles for this page -->
      <link href="../vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="../css/custom.css">

      </link>

   </head>
                        <body id="page-top">
                          <!-- Page Wrapper -->
                          <div id="wrapper">
                            <!-- Sidebar -->
                           
                            <!-- End of Topbar -->
                            <!-- Begin Page Content -->
                            <div class="container-fluid">
                              <!-- Page Heading -->
                              <?php
if(isset($_REQUEST['submit'])){
      $state=$_REQUEST['state'];
      $city=$_REQUEST['city'];
     $statecode=$_REQUEST['statecode'];
   
   
      $mobileno=$_REQUEST['mobileno'];
     
      $email=$_REQUEST['email'];
     $name=$_REQUEST['name'];
      $country=$_REQUEST['country'];
      $pin=$_REQUEST['pin'];
      $address1=$_REQUEST['address1'];
     


     
         

if(!isset($Err)){

        
   
          $sql="INSERT INTO customer_registration(name,address1,
          country,state,city,statecode,pin,mobileno,email) values('$name','$address1','$country',
          '$state','$city','$statecode', '$pin','$mobileno',
          '$email')";


        $qu= mysqli_query($connection,$sql);
       
$Err1="Customer has been successfully created.  Go to 
                              <button class='btn btn-primary '>
                                <a class='text-white'href='display_customer.php'>Back </a>
                              </button>";
                              header('location:display_customer.php');


       
 
}
}


?>
                             
                              <body class="bg-gradient-">
                                <div class="container">
                                 
  <?php if(isset($Err)){ ?><div class="alert visible alert-danger" role="alert"> <?php echo $Err; ?> </div><?php } ?>
  <?php if(isset($Err1)){ ?><div class="alert visible alert-success" role="alert"> <?php echo $Err1; ?> </div><?php } ?>
                                  <a href="display_customer.php">
                                    <button class="btn btn-sm btn-primary m-2">Back</button>
                                  </a>
                                  <div class="row">
                                    <!-- <div class="col-lg-4 d-none d-lg-block bg-register-image"></div> -->
                                    <div class="col-lg-12 ">
                                      <div class="card o-hidden border-0 shadow-lg my-1">
                                        <div class="modal-header bg-primary">
                         <h3 class=" h4 mb-1 text-white text-center">New Customer Form</h3>
                                       </div>
          
                                        <div class="card-body p-2">
                                          <!-- Nested Row within Card Body -->
                                          <div class="p-3">
                                              <form class="user" onsubmit="return validateForm()" id="myform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"  >
                                              <!--<form class="user" method="post" action="display_customer.php">-->
                                            

                                              <div class="form-row">
                                             
                        
                       
                                                   
                                                  
                                                  <div class="col-md-4 mb-3">
                                                    <b>
                                                      <label>Customer Name:</label>
                                                      <sup class="text-danger font-weight-bold"></sup>
                                                    </b>
                                                    <input type="text" maxlength="40" class="form-control "  id="name" name="name" onBlur="checkAvailability()">
                                                    <span  id="user-availability-status"></span>
                       <p><img src="LoaderIcon.gif" id="loaderIcon" style="display:none" /></p>
                                                    </div>
                                                     <div class="col-md-4 mb-3">
                                                     <div class="form-row">
                                                    

                                                                <b>
                                                                  <label>Mobile No:</label>
                                                                <sup class="text-danger font-weight-bold"></sup>
                                                              </b>
                                                              <input type="text" maxlength="10" class="form-control "onchange="this.value = '+91' + this. id=" exampleLastName"  name="mobileno">
                                                                
                                                                </div>
                                                              </div>
                                                               <div class="col-md-4 mb-3">
                                                            <b>
                                                              <label>Address  :</label>
                                                              <sup class="text-danger font-weight-bold"></sup>
                                                            </b>
                                                            <input type="text" class="form-control " id="exampleLastName"  name="address1" >
                                                            </div>
                                                  </div>
                                                  
                                                         
                                                          <div class="form- row ">
                                                            <div class="col-md-4 mb-3">
                                                              <b>
                                                                  <label>Email :</label>
                                                                
                                                                </b>
                                                                <input type="text"maxlength="60" class="form-control " id="exampleLastName" name="email">
                                                                
                                                              </div>
                                                             
                                                         

                                                               <div class="col-md-4 mb-3">
                        <b><label>Country :</label></b>
                         
                      <input type="text" name="country" class="form-control" >
         
</div>
                      


                      <div  class="col-md-4 mb-3">
                        <b><label>State :</label></b>
                         
                      
                        <input type="text" name="state" class="form-control" >
</div>
                      
                    </div>
                    <div class="form-row">
                     
                      
                     <div id="gsttype" class="col-md-4 mb-3">
                        <b><label>City :</label></b>
                         
                      <input type="text" name="city" class="form-control" >
                        
<!-- <select onChange="getcode(this.value);" name="city" id="district-list" class="form-control">
<option value="">Select</option>
</select> -->
</div>
                
                          <div class="col-md-4 mb-3">
                          <b><label>State Code :</label></b>
                        
                       <!--   <select name="statecode" id="statecode" class="form-control">
<option value="">Select</option>
</select> -->
<input type="text" name="statecode" class="form-control">

                  </div>


                   <div class="col-md-4 mb-3">
                                                                  <b>
                                                                    <label>Pin Code :</label><sup class="text-danger font-weight-bold"></sup>
                                                                  </b>
                                                                  <input type="text" maxlength="6" class="form-control " id="exampleLastName" name="pin">
                                                                  </div>

                </div>

                 
                                                            
                                                                   
                                                                    
                                                                          
                                                                              
                                                                            
                                                                              <div class="float-right col-md-4">
                                                                                <input  name="submit" type="submit" class="btn btn-primary  text-black  btn-block">
                                                                                </div>
                                                                               
                                                                              </form>
                                                                            </div>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                           
    
                                                            </div>
                                                            <!-- End of Content Wrapper -->
                                                          </div>
                                                          <!-- End of Page Wrapper -->
                                                          <!-- Scroll to Top Button-->
                                                          <a class="scroll-to-top rounded" href="#page-top">
                                                            <i class="fas fa-angle-up"></i>
                                                          </a>
                                                          <!-- Logout Modal-->
                                                          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                              <div class="modal-content">
                                                                <div class="modal-header">
                                                                  <h5 class="modal-title " id="exampleModalLabel">Ready to Leave?</h5>
                                                                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">×</span>
                                                                  </button>
                                                                </div>
                                                                <div class="modal-body ">Select "Logout" below if you are ready to end your current session.</div>
                                                                <div class="modal-footer">
                                                                  <button class="btn btn-light secondary" type="button" data-dismiss="modal">Cancel</button>
                                                                  <a class="btn btn-light secondary" href="../logout.php">Logout</a>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>




       <script type="text/javascript">
    $('body').on('keydown', 'input, select', function(e) {
    if (e.key === "Enter") {
        var self = $(this), form = self.parents('form:eq(0)'), focusable, next;
        focusable = form.find('input,a,select,button,textarea').filter(':visible');
        next = focusable.eq(focusable.index(this)+1);
        if (next.length) {
            next.focus();
        } else {
            form.submit();
        }
        return false;
    }
});
</script>


                                                        </body>
                                                      </html>


       <script type="text/javascript">
    $(function () {
               $("#selectgsttype").change(function () {

            if ($(this).val() == "Yes") {
                $("#gstlength").show();
                 $("#panlength").show();
            } else {
                $("#panlength").hide();
                $("#gstlength").hide();
            }

            
        });
    });
</script>



             
                                                      <script>
function getdistrict(val) {
  $.ajax({
  type: "POST",
  url: "get_district.php",
  data:'state_id='+val,
  success: function(data){
    $("#district-list").html(data);
  }
  });
}
</script>
<script type="text/javascript">
  function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'name='+$("#name").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>
<script>
function getcode(val) {
  $.ajax({
  type: "POST",
  url: "get_citycode.php",
  data:'state_id='+val,
  success: function(data){
    $("#statecode").html(data);
  }
  });
}
</script>  
