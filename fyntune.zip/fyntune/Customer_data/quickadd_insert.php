<?php
include "../connect.php";



$name=$_POST['name'];
$mobileno=$_POST['mobileno'];
$email=$_POST['email'];
$vehicleno=$_POST['vehicleno'];

   
 $q=mysqli_query($connection,"select refcustomer from customer_registration ORDER BY id DESC LIMIT 1");
$row=mysqli_fetch_assoc($q);
if(isset($row['refcustomer'])){
$X=$row['refcustomer']+1;
$SO ='C'.$X;
}
else{
   $n1="SELECT * FROM  number_range  WHERE id='1' ";
                       $n2=mysqli_query($connection,$n1);
                       $n3=mysqli_fetch_assoc($n2);
                    
$X=$n3['customercode'];
$SO ='C'.$X;
}





     //  $refcustomer=$_REQUEST['refcustomer'];
     // $customercode=$_REQUEST['customercode'];
         

if(!isset($Err)){

        
   
          $sql="INSERT INTO customer_registration(refcustomer,customercode,name,type,gsttype,gst,address1,
          country,state,city,statecode,pin,pan,contact_person,mobileno,fax,email,bankname,acno,
          bankkey,reconsilationac,balance, credit,debit,enabled,typevehicle,vehicleno,km) values('$X','$SO','$name','Domestic','NA',
          'NA','NA','India',
          'Maharastra','Pune','27', '111111','NA','NA','$mobileno','NA',
          '$email','NA','NA','NA','NA','NA' ,'NA','0','Y','NA','$vehicleno','NA')";


        $qu= mysqli_query($connection,$sql);
        if($qu){

         $ss="INSERT INTO account_generalledger (Accountledgername,Customerid,Accountgroup,Accountno,Openingbalance,Description,Accounttype) VALUES('$name','$SO','Account Receivable','100001','0','','Other')";
            $Q=mysqli_query($connection,$ss);



$Err1=$SO.' '."Customer has been successfully created.  Go to 
                              <button class='btn btn-primary '>
                                <a class='text-white'href='../sale/create_sale.php'>Back </a>
                              </button>";
                               header('location:../sale/create_sale.php');
        }else{
          $Err=mysqli_error($connection);
        }

       
 // header("location:material_table.php");
     //header("location:display_customer.php");
}




?>