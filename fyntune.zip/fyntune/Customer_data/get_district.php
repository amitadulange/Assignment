<?php
require_once("../connect.php");
if(!empty($_POST["state_id"])) 
{
$query1 =mysqli_query($connection,"SELECT * FROM state WHERE StateName = '" . $_POST["state_id"] . "'");
while($row1=mysqli_fetch_array($query1)) 

{
	$code=$row1["id"];

$query =mysqli_query($connection,"SELECT * FROM city WHERE StCode = $code");

?>
<option value="">Select District</option>
<?php
while($row=mysqli_fetch_array($query))  
{
?>
<option value="<?php echo $row["CityName"]; ?>"><?php echo $row["CityName"]; ?></option>
<?php
}
}
}
?>
