<?php
require_once("../connect.php");
// $db_handle = new DBController();


if(!empty($_POST["name"])) {
  $query = "SELECT * FROM customer_registration WHERE name='" . $_POST["name"] . "'";
 $result= mysqli_query($connection, $query);
  $user_count=mysqli_num_rows($result);
  if($user_count>0) {
      echo "<span class='status-not-available text-danger'> Customer Name Already Register.<b> enter New number</b>.</span>";
  }else{
      echo "<span class='status-available text-success'> <b> Customer Name  Accepted.</b></span>";
  }
}


?>

