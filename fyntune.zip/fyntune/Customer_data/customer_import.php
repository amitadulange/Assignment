    <?php
    require_once('../connect.php');

     if(isset($_POST["upload"])){
        
        $filename=$_FILES["file"]["tmp_name"];    
         if($_FILES["file"]["size"] > 0)
         {
            $file = fopen($filename, "r");
              while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
               {


$q=mysqli_query($connection,"select refcustomer from customer_registration ORDER BY id DESC LIMIT 1");
$row=mysqli_fetch_assoc($q);
if(isset($row['refcustomer'])){
$X=$row['refcustomer']+1;
$SO ='C'.$X;
}
else{
 
   $n1="SELECT * FROM  number_range  WHERE id='1' ";
   $n2=mysqli_query($connection,$n1);
   $n3=mysqli_fetch_assoc($n2);
   $X=$n3['customercode'];
   $SO ='C'.$X;
}


          $sql = "INSERT INTO customer_registration(refcustomer,customercode,name,type,gsttype,gst,address1,
          country,state,city,statecode,pin,pan,contact_person,mobileno,fax,email,bankname,acno,
          bankkey,reconsilationac,enabled,balance,credit,debit,typevehicle,vehicleno,km)
                       values ('$X','$SO','".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','".$getData[6]."','".$getData[7]."','".$getData[8]."','".$getData[9]."','".$getData[10]."','".$getData[11]."','".$getData[12]."','".$getData[13]."','".$getData[14]."','".$getData[15]."','".$getData[16]."','".$getData[17]."','".$getData[18]."','Y','0','Debit','".$getData[19]."','".$getData[20]."','".$getData[21]."','".$getData[22]."')";
                       $result = mysqli_query($connection, $sql);
 
 $ss="INSERT INTO account_generalledger (Accountledgername,Customerid,Accountgroup,Accountno,Openingbalance,Description,Accounttype) VALUES('".$getData[0]."','$SO','Account Receivable','100001','".$getData[19]."','','Customer')";
$Q=mysqli_query($connection,$ss);


                       
            if(!isset($result))
            {
              echo "<script type=\"text/javascript\">
                  alert(\"Invalid File:Please Upload CSV File.\");
                  window.location = \"display_customer.php\"
                  </script>";    
            }
            else {
                echo "<script type=\"text/javascript\">
                alert(\"CSV File has been successfully Imported.\");
                window.location = \"display_customer.php\"
              </script>";
              // header("location:display_vendor.php");
            }
               }
          
               fclose($file);  
         }else{
        echo "<script type=\"text/javascript\">
                alert(\"Please Select File.\");
                window.location = \"display_customer.php\"
              </script>";
      }

      }   
     ?>