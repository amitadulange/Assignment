-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 28, 2020 at 06:19 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sberp`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_registration`
--

DROP TABLE IF EXISTS `customer_registration`;
CREATE TABLE IF NOT EXISTS `customer_registration` (
  `id` int(40) NOT NULL AUTO_INCREMENT,
  `refcustomer` int(40) NOT NULL,
  `customercode` varchar(80) NOT NULL,
  `name` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `gsttype` varchar(40) NOT NULL,
  `gst` varchar(15) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `country` varchar(18) NOT NULL,
  `state` varchar(80) NOT NULL,
  `city` varchar(40) NOT NULL,
  `statecode` varchar(20) NOT NULL,
  `pin` varchar(20) NOT NULL,
  `pan` varchar(40) NOT NULL,
  `contact_person` varchar(40) NOT NULL,
  `mobileno` varchar(40) NOT NULL,
  `fax` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  `bankname` varchar(40) NOT NULL,
  `acno` varchar(40) NOT NULL,
  `bankkey` varchar(40) NOT NULL,
  `reconsilationac` varchar(40) NOT NULL,
  `balance` varchar(40) NOT NULL,
  `credit` varchar(40) NOT NULL,
  `debit` varchar(40) NOT NULL,
  `enabled` varchar(40) NOT NULL,
  `typevehicle` varchar(40) NOT NULL,
  `vehicleno` varchar(40) NOT NULL,
  `km` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1035 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_registration`
--

INSERT INTO `customer_registration` (`id`, `refcustomer`, `customercode`, `name`, `type`, `gsttype`, `gst`, `address1`, `country`, `state`, `city`, `statecode`, `pin`, `pan`, `contact_person`, `mobileno`, `fax`, `email`, `bankname`, `acno`, `bankkey`, `reconsilationac`, `balance`, `credit`, `debit`, `enabled`, `typevehicle`, `vehicleno`, `km`) VALUES
(1034, 10020, 'C10020', 'M/S Shree Gajanan Engg.', 'MANUAL', 'Yes', '27APTPK7740M1Z1', 'Chinchwad ,Pune', 'India', 'Maharashtra', 'Pune', '27', '', 'APTPK7740M', '', '9823809150', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14DF8866', ''),
(1033, 10019, 'C10019', 'Laxman Kawade', 'MANUAL', 'No', '', 'Thergaon', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '9850836315', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14CX4432', ''),
(1032, 10018, 'C10018', 'M/S AIM Service Solutions', 'MANUAL', 'No', '', 'Aurangabad', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '7276033292', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14CX2307', ''),
(1030, 10016, 'C10016', 'Vinod Shingare', 'MANUAL', 'No', '', 'Chichwad', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '9604769999', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14CK3618', ''),
(1031, 10017, 'C10017', 'M/S N.N .Industries', 'MANUAL', 'No', '', 'Bhosari', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '9822409368', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14CK8453', ''),
(1029, 10015, 'C10015', 'M/s Salunke Cycle Trader', 'MANUAL', 'No', '', 'Near pimpri Railway station  pimpri,Pune', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '9850893107', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14BX3266', ''),
(1028, 10014, 'C10014', 'Anil Jadhav', 'MANUAL', 'No', '', 'Thergaon', 'India', 'Maharashtra', '', '27', '', '', '', '9623303080', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14BA0500', ''),
(1027, 10013, 'C10013', 'Sambhaji Barane', 'MANUAL', 'No', '', 'Thergaon', 'India', 'Maharashtra', '', '27', '', '', '', '9881197777', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH14AV1800', ''),
(1026, 10012, 'C10012', 'M/S Sachin Tours And Travels', 'MANUAL', 'No', '', 'Tathawade', 'India', 'Maharashtra', 'Tathawade', '27', '', '', '', '9823454000', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12NX3868', ''),
(1024, 10010, 'C10010', 'Mahesh Nikte', 'MANUAL', 'No', '', 'Kotharud', 'India', 'Maharashtra', 'pune', '27', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12GZ6455', ''),
(1025, 10011, 'C10011', 'M/S OM A TRAVELS', 'MANUAL', 'Yes', '27ATCPB4599G1ZL', 'Pimple Gurav', 'India', 'Maharashtra', 'Pimple Gurav', '27', '', 'ATCPB4599G', '', '9823060506', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12NB0179', ''),
(1023, 10009, 'C10009', 'Vijay Ware', 'MANUAL', 'No', '', '', 'India', 'Maharashtra', 'Pune', '27', '', '', '', '9623303050', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12FZ1422', ''),
(1022, 10008, 'C10008', 'Kunal Icon Pimple saudagar', 'MANUAL', 'Yes', '27AEOPP8228B1ZA', 'pune', 'India', 'Maharashtra', 'Pune', '27', '', 'AEOPP8228B', '', '9823290923', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12FY9243', ''),
(1021, 10007, 'C10007', 'Gurukrupa enterprises', 'MANUAL', 'Yes', '27ACPPN0840G1ZJ', 'Pirangut', 'India', 'Maharashtra', 'pirangut', '27', '', 'ACPPN0840G', '', '9822198167', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12DS4330', ''),
(1020, 10006, 'C10006', 'AJIT SIR', 'MANUAL', 'No', '', '', 'India', 'Maharashtra', '', '27', '', '', '', '9021139129', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH12CK3148', ''),
(1019, 10005, 'C10005', 'DATTA KANJALE', 'MANUAL', 'No', '', 'Kotharud', 'India', 'Maharashtra', 'kothrud', '27', '', '', '', '9049061227', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH11BD6443', ''),
(1018, 10004, 'C10004', 'SHIRISH PATIL', 'MANUAL', 'No', '', 'KAJI', 'India', 'Maharashtra', 'KAJI', '27', '', '', '', '9422745942', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH11AF0909', ''),
(1017, 10003, 'C10003', 'SHIRISH UMADI', 'MANUAL', 'No', '', 'RAHATANI', 'India', 'Maharashtra', 'RAHATANI', '27', '', '', '', '8329954874', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH10BM2983', ''),
(1016, 10002, 'C10002', 'Raghunandan petroleam', 'MANUAL', 'Yes', '27AMJPG7434M1ZM', 'Tathawade', 'India', 'Maharashtra', '', '27', '', 'AMJPG7434M', '', '9763733444', '', '', '', '', '', '', '', '', '', 'Y', '', 'MH02DS9991', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
