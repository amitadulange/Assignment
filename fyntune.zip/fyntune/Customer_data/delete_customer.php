<?php
session_start();
require_once('../connect.php');

if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
  //$smsg = "Already Logged In" . $_SESSION['username'];
  header('location:index.php');
}

$id=$_GET['id'];
$query1 = "DELETE FROM customer_registration WHERE id=$id";

mysqli_query($connection,$query1);

header('location:display_customer.php');

?>