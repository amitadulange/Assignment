<?php
include "../connect.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>

<div class="container">
<form method="POST" action="../Customer_data/quickadd_insert.php" >
  <div class="row">

                                                  <div class="col-sm-3">
                                                    <b>
                                                      <label> Vehicle Number:</label></b>
                                                      
                                                    </b>
                                                    <input type="text"  class="form-control " id="exampleLastName"  name="name">
                                                    </div>

                                                   <div class="col-sm-3"><b>
                                                      <label> Mobile Number</label></b>
                                                      <input type="text" maxlength="10" name="mobileno" class="form-control" id="mobileno">
                                                    </div>

                                                    <div class="col-sm-5"><b>
                                                      <label>Email</label></b>
                                                      <input type="text"  name="email" class="form-control" id="email">
                                                    </div>
                                                   <div class="col-sm-5"><b>
                                                      <label> Customer Address</label></b>
                                                      <input type="text" maxlength="25" name="address1" class="form-control" id="vehicleno">
                                                    </div>
                                                    
</div>
<br>
<div class="float-right col-md-3">
                                                                                <input  name="submit" type="submit" class="btn btn-primary  text-black  btn-block">
                                                                                </div>
                                                                              </div>
                                                                              </form>

</body>
</html>





