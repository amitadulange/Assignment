
<?php

require_once('../connect.php');
error_reporting(0);

	if(isset($_POST['exportdata']))
	{
		$result=$connection->query("select * from customer_registration");
	if(mysqli_num_rows($result) > 0)
	 {
		  $output .= '
		   <table class="table" bordered="1">  
		                    <tr>  
		                      <th>Id</th>
    <th>Customer Code</th>
    <th>Vehicle Number</th>
    <th>Type</th>
    <th>GST Type</th>
    <th>GST No</th>
    
    <th>Address </th>
    
    <th>Country</th>
    <th>State</th>
    <th>City</th>
    <th>State Code</th>
    <th>Pin Code</th>
    <th>PAN No</th>
    <th>Contact Person</th>
    
    <th>Mobile No</th>
    <th>FAX No</th>
    <th>Email Id</th>
    <th>Bank Name</th>
    <th>A/C No</th>
    <th>Bank Key</th>
    <th>Reconsilation A/C</th>
    <th>Opening Balance</th>
    <th>Type</th>
    <th>Debit</th>
    <th>Enable/Disable</th>
   
		                         

		       
		                    </tr>
		  ';
	  while($row = mysqli_fetch_array($result))
	  {
	   $output .= '
	    				<tr>   
	    				<td>'. $row['id'].'</td>
					    <td>'. $row['customercode'].'</td>
					    <td>'. $row['name'].'</td>
					    <td>'. $row['type'].'</td>
					     <td>'. $row['gsttype'].'</td>
					    <td>'. $row['gst'].'</td>
					    
					    <td>'. $row['address1'].'</td>
					    <td>'. $row['country'].'</td>
					    <td>'. $row['state'].'</td>
					    <td>'. $row['city'].'</td>
					    <td>'. $row['statecode'].'</td>
					    <td>'. $row['pin'].'</td>
					    <td>'. $row['pan'].'</td>
					    <td>'. $row['contact_person'].'</td>
					    <td>'. $row['mobileno'].'</td>
					    <td>'. $row['fax'].'</td>
					    <td>'. $row['email'].'</td>
					   <td>'. $row['bankname'].'</td>
					    <td>'. $row['acno'].'</td>
					    <td>'. $row['bankkey'].'</td>
					    <td>'. $row['reconsilationac'].'</td>
					     <td>'. $row['balance'].'</td>
					     <td>'. $row['	credit'].'</td>
					      <td>'. $row['debit'].'</td>
					    <td>'. $row['enabled'].'</td>

	                    </tr>
				   ';
	  }
	  $output .= '</table>';
	 
	  header('Content-Type: application/xls');
	  header('Content-Disposition: attachment; filename=download.xls');
	  echo $output;

	 }
	}

?>