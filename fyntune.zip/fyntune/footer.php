<!DOCTYPE html>
<html>
<head>
	<title>Footer</title>
</head>
<body>
<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">

          	<p>© 2021 Enterprise resource planning. All rights reserved | Design by
		<a href="http://pspmerp.com">PSPM Technology Pvt Ltd.</a>
            <!-- <span>Copyright &copy; PSPM Group 2019</span> -->
          </div>
        </div>
      </footer>
</body>
</html>
