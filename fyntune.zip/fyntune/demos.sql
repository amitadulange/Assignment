-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 07, 2021 at 06:59 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demos`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_registration`
--

DROP TABLE IF EXISTS `customer_registration`;
CREATE TABLE IF NOT EXISTS `customer_registration` (
  `id` int(40) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `country` varchar(18) NOT NULL,
  `state` varchar(80) NOT NULL,
  `city` varchar(40) NOT NULL,
  `statecode` varchar(20) NOT NULL,
  `pin` varchar(20) NOT NULL,
  `mobileno` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1035 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_registration`
--

INSERT INTO `customer_registration` (`id`, `name`, `address1`, `country`, `state`, `city`, `statecode`, `pin`, `mobileno`, `email`) VALUES
(1034, 'M/S Shree Gajanan Engg.', 'Chinchwad ,Pune', 'India', 'Maharashtra', 'sangali', '27', '', '9823809150', ''),
(1033, 'Laxman Kawade', 'Thergaon', 'India', 'Maharashtra', 'Pune', '27', '', '9850836315', ''),
(1032, 'M/S AIM Service Solutions', 'Aurangabad', 'India', 'Maharashtra', 'Pune', '27', '', '7276033292', ''),
(1030, 'Vinod Shingare', 'Chichwad', 'India', 'Maharashtra', 'Pune', '27', '', '9604769999', ''),
(1031, 'M/S N.N .Industries', 'Bhosari', 'India', 'Maharashtra', 'Pune', '27', '', '9822409368', ''),
(1029, 'M/s Salunke Cycle Trader', 'Near pimpri Railway station  pimpri,Pune', 'India', 'Maharashtra', 'Pune', '27', '', '9850893107', ''),
(1028, 'Anil Jadhav', 'Thergaon', 'India', 'Maharashtra', 'Pune', '27', '', '9623303080', 'a@gmail.com'),
(1027, 'Sambhaji Barane', 'Thergaon', 'India', 'Maharashtra', 'Pune', '27', '', '9881197777', 'S@gmail.com'),
(1026, 'M/S Sachin Tours And Travels', 'Tathawade', 'India', 'Maharashtra', 'Tathawade', '27', '', '9823454000', ''),
(1024, 'Mahesh Nikte', 'Kotharud', 'India', 'Maharashtra', 'pune', '27', '', '', ''),
(1025, 'M/S OM A TRAVELS', 'Pimple Gurav', 'India', 'Maharashtra', 'Pimple Gurav', '27', '', '9823060506', ''),
(1023, 'Vijay Ware', '', 'India', 'Maharashtra', 'Pune', '27', '', '9623303050', ''),
(1022, 'Kunal Icon Pimple saudagar', 'pune', 'India', 'Maharashtra', 'Pune', '27', '', '9823290923', ''),
(1021, 'Gurukrupa enterprises', 'Pirangut', 'India', 'Maharashtra', 'pirangut', '27', '', '9822198167', ''),
(1020, 'AJIT SIR', '', 'India', 'Maharashtra', '', '27', '', '9021139129', ''),
(1019, 'DATTA KANJALE', 'Kotharud', 'India', 'Maharashtra', 'kothrud', '27', '', '9049061227', ''),
(1018, 'SHIRISH PATIL', 'KAJI', 'India', 'Maharashtra', 'KAJI', '27', '', '9422745942', ''),
(1017, 'SHIRISH UMADI', 'RAHATANI', 'India', 'Maharashtra', 'RAHATANI', '27', '', '8329954874', ''),
(1016, 'Raghunandan petroleam', 'Tathawade', 'India', 'Maharashtra', '', '27', '', '9763733444', '');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(12) NOT NULL,
  `last_name` varchar(12) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `department` varchar(40) NOT NULL,
  `role` varchar(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `profilepic` varchar(255) DEFAULT NULL,
  `custpermission` char(1) DEFAULT NULL,
  `venpermission` char(1) DEFAULT NULL,
  `matpermission` char(1) DEFAULT NULL,
  `prpermission` char(1) DEFAULT NULL,
  `userpermission` char(1) DEFAULT NULL,
  `popermission` char(1) DEFAULT NULL,
  `grnpermission` char(1) DEFAULT NULL,
  `accpermission` char(1) DEFAULT NULL,
  `invenpermission` char(1) DEFAULT NULL,
  `settpermission` char(1) DEFAULT NULL,
  `panno` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `birth_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `first_name`, `last_name`, `username`, `email`, `mobile_no`, `password`, `department`, `role`, `date`, `profilepic`, `custpermission`, `venpermission`, `matpermission`, `prpermission`, `userpermission`, `popermission`, `grnpermission`, `accpermission`, `invenpermission`, `settpermission`, `panno`, `address`, `birth_date`) VALUES
(28, 'Auth', 'User', 'Auth', 'auth@gmail.com', '788888888', 'Auth', 'Admin', 'Admin', '2021-04-07 05:00:55', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL),
(29, 'Guest', 'User', 'Guest', 'guest@gmail.com', '45555555555', 'Guest', 'User', 'User', '2021-04-07 05:36:06', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
