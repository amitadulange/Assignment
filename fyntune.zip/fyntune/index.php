<?php
error_reporting(0);
session_start();
//require_once('connect.php');
require_once('connect.php');
if(isset($_SESSION['username']) & !empty($_SESSION['username'])){
  //$smsg = "Already Logged In" . $_SESSION['username'];
  header('location:dashboard.php');
}

if(isset($_POST) & !empty($_POST)){
  $username = $_POST['username'];
  $Password = $_POST['Password'];
  
  $sql = "SELECT * FROM `registration` WHERE ";
  if($username){
    $sql .= "username='$username'";
  }
  $sql .= " AND password='$Password'";
  $sql;
  $res = mysqli_query($connection, $sql);
  $count = mysqli_num_rows($res);
  if($count == 1){
    $_SESSION['username'] =$username;
    header('location:index.php');
  }else{
    $fmsg = "User does not exist";
  }
  
}
?>

<!DOCTYPE html>
<html>
<head>
    
  <title>Login page</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <!-- <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <link href="css/login.css" rel="stylesheet"> -->
</head>
<body>
     <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>
      <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['email'])) : ?>
      <p>Welcome <strong><?php echo $_SESSION['email']; ?></strong></p>
      <p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
</div>
<div class="card p-5 card1 container">
    <div class="row d-flex justify-content-center">
        <div class="col-md-10">

            <div class="card">
                <div class="row no-gutters">
                    <div class="col-md-4 first">
                        <div class="linkedin"><span class="no-gutters text-primary font-weight-bold"> </span><span class="in"></span></div>
                    </div>
                    <div class="col-md-6 second pl-4 pr-4">
                        <h4 class="welcome text-primary">Welcome</h4>
                        

                    <form class="user" method="POST" onsubmit="return validateForm()" id="myform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder=" Username" name="username" >
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" name="Password" >
                    </div>
                    <button name="login" type="submit" class="btn btn-primary btn-user btn-block">
                      Login
                    </button>
                    <hr>
                    
                  </form>

                      <!--   <div class="row">
                            <div class="col-sm-4 under"> <span>Copyright Policy</span>
                                <p>User Agreement</p>
                            </div>
                            <div class="col-sm-3 under"> <span>Privacy Policy</span>
                                <p>Cookie Policy</p>
                            </div>
                            <div class="col-sm-4 under"> <span>Send Feedback</span>
                                <p>Community Guidelines</p>
                            </div>
                            <div class="col-md-1    ">
                                <p> </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <p class="lower">Pspm Technology &#169 2020</p>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>