<?php

require_once('connect.php'); 

?>
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">PSPM GROUP</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
       <li class="nav-item">
        <a class="nav-link" href="../dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
       
<?php if(($r['custpermission']=='Y' && $r['role']=="User") || ($r['custpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="../Customer_data/display_customer.php" data-toggle="collapse" data-target="#customer" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-users"></i>
          <span>Customer</span>
        </a>
        <div id="customer" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../Customer_data/add_customer.php">Add New Customer</a>
            <a class="collapse-item" href="../Customer_data/display_customer.php">Customer List</a>
            
          </div>
        </div>
      </li>'; }?> 
	  
<?php if(($r['venpermission']=='Y' && $r['role']=="User") || ($r['venpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="../Vendor_data/display_vendor.php" data-toggle="collapse" data-target="#vendor" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-users"></i>
          <span>Vendor</span>
        </a>
        <div id="vendor" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" accesskey="v" href="../Vendor_data/add_vendor.php">Add New Vendor</a>
            <a class="collapse-item" href="../Vendor_data/display_vendor.php">Vendor List</a>
            
          </div>
        </div>
      </li>'; }?>  

<?php if(($r['matpermission']=='Y' && $r['role']=="User") || ($r['matpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
      <li class="nav-item">
        <a class="nav-link collapsed" href="../Material_data/material_table.php" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-shopping-cart"></i>
          <span>Material Master</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded"> 
			<a class="collapse-item" href="../Material_data/add_material.php">Add New Material</a>
            <a class="collapse-item" href="../Material_data/material_table.php">Material Master</a>
            <a class="collapse-item" href="../Material_data/material_storage.php">Storage Location</a>
            <a class="collapse-item" href="../Material_data/material_material_type.php">Material Type</a>
            <a class="collapse-item" href="../Material_data/material_uom.php">UOM</a>
            <a class="collapse-item" href="../Material_data/material_hsncode.php">Material HSN Code</a>
            <a class="collapse-item" href="../Material_data/material_group.php">Material Group</a>
             <a class="collapse-item" href="../Material_data/material_brand.php">Material Brand</a>
             <a class="collapse-item" href="../Material_data/expiry_material.php">Material Settings</a>
            <a class="collapse-item" href="../Plant/createplant.php">Create Plant</a>
            <a class="collapse-item" href="../Plant/plantlist.php">Plant List</a>
           </div>
        </div>
      </li>'; }?>


<?php if(($r['grnpermission']=='Y' && $r['role']=="User") || ($r['grnpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="../grn/grnlist.php" data-toggle="collapse" data-target="#grn" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fa fa-edit"></i>
          <span>Purchase Invoice</span>
        </a>
        <div id="grn" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../grn/grn.php">New Purchase Invoice</a>
            <a class="collapse-item" accesskey="g" href="../grn/grnlist.php">Purchase Invoice List</a>
              <a class="collapse-item" href="../grn/display_grnreturn.php">Purchase Return List</a>
             <a class="collapse-item" href="../grn/display_creditnote.php">Credit Note List</a>
          </div>
        </div>
      </li>'; }?>

<?php if(($r['popermission']=='Y' && $r['role']=="User") || ($r['popermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed"  href="../sale/display_sale.php" data-toggle="collapse" data-target="#sale" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-chart-line"></i>
          <span>Sales</span>
        </a>
        <div id="sale" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../sale/create_sale.php">New Sales</a>
            <a class="collapse-item" accesskey="s"  href="../sale/display_sale.php"> Sales List</a>
             <a class="collapse-item" href="../sale/duepayment_sale.php"> Due List</a>
             <a class="collapse-item" href="../sale/display_returnsale.php">Sales Return List</a>

             <a class="collapse-item" href="../sale/due_returnpaidlist.php">Due Return List</a>
             <a class="collapse-item" href="../sale/debitlist.php">Debit List</a>
          </div>
        </div>
      </li>'; }?>

      <?php if(($r['popermission']=='Y' && $r['role']=="User") || ($r['popermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="../Chalan/DC.php" data-toggle="collapse" data-target="#Chalan" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-chart-line"></i>
          <span>Chalan</span>
        </a>
        <div id="Chalan" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           <a class="collapse-item" href="../Chalan/jobwork.php">New jobwork</a>
            <a class="collapse-item" href="../Chalan/jobworklist.php">jobwork list</a>
            <a class="collapse-item" href="../Chalan/DC.php">New DC</a>
            <a class="collapse-item" href="../Chalan/dclist.php"> DC List</a>
             <a class="collapse-item" href="../Chalan/vareceived_list.php"> Vendor Received List</a>
             <a class="collapse-item" href="../Chalan/dcreturn_list.php">Return list</a>

          </div>
        </div>
      </li>'; }?>  

<?php if(($r['prpermission']=='Y' && $r['role']=="User") || ($r['prpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#Estimate" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-chart-line"></i>
          <span>Job Card & Estimate</span>
        </a>
        <div id="Estimate" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../jobcard/jobcard.php">New Job Card</a>
            <a class="collapse-item" href="../jobcard/jobcardlist.php">Job Card List</a>
             <a class="collapse-item" href="../jobcard/display_estimate.php">Estimate List</a>
            
            
          </div>
        </div>
      </li>'; }?>  
      <?php if(($r['prpermission']=='Y' && $r['role']=="User") || ($r['prpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#production" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-chart-line"></i>
          <span>Production</span>
        </a>
        <div id="production" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../production/create_bom.php">Create BOM</a>
            <a class="collapse-item" href="../production/display_bom.php">BOM List</a>
             <a class="collapse-item" href="../production/production_order.php">New Production Order</a>
             <a class="collapse-item" href="../production/display_productionorder.php">Production Order List</a>
            <a class="collapse-item" href="../production/display_goodesrecipt.php"> Goods Receipt list</a>
             <a class="collapse-item" href="../production/display_goodsissue.php">Goods Issue List</a>
             <a class="collapse-item" href="../production/create_employe.php">Create Employee</a>


            
            
          </div>
        </div>
      </li>'; }?>  



<?php if(($r['invenpermission']=='Y' && $r['role']=="User") || ($r['invenpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="../Inventry/inventry.php" data-toggle="collapse" data-target="#inventry" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Inventory</span>
        </a>
        <div id="inventry" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../Inventry/inventry.php">Stock List</a>
            
          </div>
        </div>
      </li>'; }?>   


<?php if(($r['accpermission']=='Y' && $r['role']=="User") || ($r['accpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="../Account/Genral_ledger.php" data-toggle="collapse" data-target="#account" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-landmark"></i>
          <span>Account</span>
        </a>
        <div id="account" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../Account/COA.php">COA</a>
            <a class="collapse-item" href="../Account/Genral_ledger.php">GL</a>
             <a class="collapse-item" href="../Account/advancepayment.php">Payments</a>
              <a class="collapse-item" href="../Account/voucher_status.php">Voucher List</a>
               <a class="collapse-item" href="../Account/add_voucher.php">New Voucher</a>
               <a class="collapse-item" href="../Account/reports.php">Reports</a>
                <a class="collapse-item" href="../Account/bankentry.php">Bank Entry</a>
                <a class="collapse-item" href="../Expenses/expenses.php">Expenses</a>
                <a class="collapse-item" href="../capital_goods/capital_goods.php">Capital Goods/ Assest</a>


          </div>
        </div>
      </li>'; }?>    


<?php if(($r['userpermission']=='Y' && $r['role']=="User") || ($r['userpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'
       <li class="nav-item">
        <a class="nav-link collapsed" href="../user/index.php" data-toggle="collapse" data-target="#pr" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-portrait"></i>
          <span>User</span>
        </a>
        <div id="pr" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../user/index.php">User List</a>
            <a class="collapse-item" href="../user/register.php">Add New User</a>
            
          </div>
        </div>
      </li>'; }?>



      <!-- Divider -->
     
      <hr class="sidebar-divider">
<?php if(($r['settpermission']=='Y' && $r['role']=="User") || ($r['settpermission']=='Y' && $r['role']=="HOD") || ($r['role']=="Admin")){ echo'

     <li class="nav-item">
        <a class="nav-link" href="../setting/setting.php">
          <i class="fas fa-cogs fa-sm fa-fw mr-2"></i>
          <span> Settings</span></a>
      </li>'; }?>

      
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"> <?php echo $_SESSION['username'];?> </span>
                <img alt="User Pic" src="<?php if(isset($r['profilepic']) & !empty($r['profilepic'])){ echo "$loc$pic"; }else{ echo "../img/user.png";} ?>" id="profileimage" class="img-profile rounded-circle"> 
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="../setting/user_profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="../setting/setting.php">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
      
